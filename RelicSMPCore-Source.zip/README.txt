================================================================================
                    RelicSMPCore - Minecraft Paper Plugin
                          Version 1.0.0
================================================================================

Target Environment:
- Platform: Paper (or Purpur / Spigot) 1.21.1
- Java version: Java 21+

Features Included:
1. Dynamic Relic System:
   - 5 Blessed SMP relics: Winds, Ender, Titan, Hunter, and Fortune.
   - Unique real-time owner tracking and interactive histories saved across reboots.
   - Intelligent cooldown managers per relic per player.
2. GUI Control Console:
   - Command '/relicsmpcore' or aliases '/rsc', '/relics' opens a 27-slot chest GUI.
   - Direct tab completions for seamless admin actions.
   - Beautiful visual panels: Catalog, Events Hub, Settings, and Player Records.
3. Automated Server Events:
   - Periodic random event engine with reward commands.
   - Fully customizable through configuration tables.
4. Robust Local Databases:
   - Dedicated files: 'config.yml', 'relics.yml', and 'players.yml' stored safely.
   - Seamless, efficient thread-safe auto-saves.

--------------------------------------------------------------------------------
INSTALLATION INSTRUCTIONS
--------------------------------------------------------------------------------

1. Copy the compiled JAR file 'RelicSMPCore-1.0.0.jar' into your 
   server's '/plugins' directory.
2. Boot or reload your Minecraft server (Requires Java 21 & Paper 1.21.1).
3. The plugin will automatically create a configuration folder:
   '/plugins/RelicSMPCore/' containing config.yml, relics.yml, and players.yml.
4. Customize files and execute '/relicsmpcore reload' to apply changes instantly.

--------------------------------------------------------------------------------
COMMANDS & PERMISSIONS
--------------------------------------------------------------------------------

- /relicsmpcore
  Description: Displays the primary Core control chest menu.
  Permission: relicsmpcore.use (Enabled for everyone by default)

- /relicsmpcore reload
  Description: Reloads all configurations and syncs active custom items.
  Permission: relicsmpcore.admin (OP only)

- /relicsmpcore give <player> <relic_id>
  Description: Transfers a custom active relic to the target.
  Permission: relicsmpcore.admin (OP only)

- /relicsmpcore event <start|stop>
  Description: Control scheduling or immediately fire/conclude server events.
  Permission: relicsmpcore.admin (OP only)

Enjoy your professional Relic SMP Experience!
Created by Sarithavs.
