package com.relicsmpcore.commands;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.gui.CoreMenu;
import com.relicsmpcore.models.Relic;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class RelicCoreCommand implements CommandExecutor, TabCompleter {

    private final RelicSMPCore plugin;

    public RelicCoreCommand(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                plugin.reloadPlugin();
                sender.sendMessage("RelicSMPCore Reloaded!");
                return true;
            }
            sender.sendMessage("This command is for players only.");
            return true;
        }

        Player player = (Player) sender;
        String permissionUse = plugin.getConfigManager().getPermissionUse();
        String permissionAdmin = plugin.getConfigManager().getPermissionAdmin();

        if (!player.hasPermission(permissionUse)) {
            ChatUtils.sendMessage(player, "&cYou do not have permission to use this!");
            return true;
        }

        if (args.length == 0) {
            // Open standard inventory Core GUI
            CoreMenu.open(player);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "reload":
                if (!player.hasPermission(permissionAdmin)) {
                    ChatUtils.sendMessage(player, "&cYou do not have permission to run administrative tasks!");
                    return true;
                }
                plugin.reloadPlugin();
                ChatUtils.sendMessage(player, "&aPlugin configs and relics reloaded successfully!");
                break;

            case "give":
                if (!player.hasPermission(permissionAdmin)) {
                    ChatUtils.sendMessage(player, "&cYou do not have permission to give relics.");
                    return true;
                }
                if (args.length < 3) {
                    ChatUtils.sendMessage(player, "&cUsage: /rsc give <player> <relic_id>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    ChatUtils.sendMessage(player, "&cPlayer not found.");
                    return true;
                }
                Relic relic = plugin.getRelicManager().getRelic(args[2]);
                if (relic == null) {
                    ChatUtils.sendMessage(player, "&cRelic not found! Try one of: winds, ender, titan, hunter, fortune");
                    return true;
                }
                ItemStack relicItem = plugin.getRelicManager().createRelicItemStack(relic);
                target.getInventory().addItem(relicItem);
                
                // Transfer tracking
                plugin.getRelicManager().transferOwnership(relic.getId(), target.getUniqueId());
                ChatUtils.sendMessage(player, "&aGave " + relic.getName() + " &ato &e" + target.getName());
                ChatUtils.sendMessage(target, "&aYou have been gifted the legendary " + relic.getName() + " &a!");
                break;

            case "event":
                if (!player.hasPermission(permissionAdmin)) {
                    ChatUtils.sendMessage(player, "&cNo permission.");
                    return true;
                }
                if (args.length > 1 && args[1].equalsIgnoreCase("start")) {
                    plugin.getEventManager().triggerRandomEvent();
                    ChatUtils.sendMessage(player, "&aForced a random event to start!");
                } else if (args.length > 1 && args[1].equalsIgnoreCase("stop")) {
                    plugin.getEventManager().endEvent();
                    ChatUtils.sendMessage(player, "&aForce-stopped the active event.");
                } else {
                    ChatUtils.sendMessage(player, "&cUsage: /rsc event <start|stop>");
                }
                break;

            case "fragments":
                if (args.length == 1) {
                    int balance = plugin.getRelicFragmentManager().getFragments(player.getUniqueId());
                    ChatUtils.sendMessage(player, "&bYour Relic Fragment Balance: &e" + balance);
                    return true;
                }
                
                if (!player.hasPermission(permissionAdmin)) {
                    ChatUtils.sendMessage(player, "&cYou do not have permission to manage player fragments.");
                    return true;
                }
                
                if (args.length < 4) {
                    ChatUtils.sendMessage(player, "&cUsage: /rsc fragments <player> <add|remove|set> <amount>");
                    return true;
                }
                
                Player fragTarget = Bukkit.getPlayer(args[1]);
                if (fragTarget == null) {
                    ChatUtils.sendMessage(player, "&cPlayer not found.");
                    return true;
                }
                
                String op = args[2].toLowerCase();
                int amount;
                try {
                    amount = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    ChatUtils.sendMessage(player, "&cAmount must be a valid integer!");
                    return true;
                }
                
                if (op.equals("add")) {
                    plugin.getRelicFragmentManager().addFragments(fragTarget.getUniqueId(), amount);
                    int current = plugin.getRelicFragmentManager().getFragments(fragTarget.getUniqueId());
                    ChatUtils.sendMessage(player, "&aAdded &e" + amount + " &afragments to &b" + fragTarget.getName() + "&a. (New total: &6" + current + "&a)");
                    ChatUtils.sendMessage(fragTarget, "&aYou received &e" + amount + " &aRelic Fragments! (Total: &6" + current + "&a)");
                } else if (op.equals("remove")) {
                    boolean success = plugin.getRelicFragmentManager().removeFragments(fragTarget.getUniqueId(), amount);
                    if (success) {
                        int current = plugin.getRelicFragmentManager().getFragments(fragTarget.getUniqueId());
                        ChatUtils.sendMessage(player, "&aRemoved &e" + amount + " &afragments from &b" + fragTarget.getName() + "&a. (New total: &6" + current + "&a)");
                        ChatUtils.sendMessage(fragTarget, "&c" + amount + " &aRelic Fragments were removed from your balance. (Total: &6" + current + "&a)");
                    } else {
                        ChatUtils.sendMessage(player, "&cPlayer does not have enough fragments to remove!");
                    }
                } else if (op.equals("set")) {
                    plugin.getRelicFragmentManager().setFragments(fragTarget.getUniqueId(), amount);
                    ChatUtils.sendMessage(player, "&aSet &b" + fragTarget.getName() + "&a's fragment balance to &6" + amount + "&a.");
                    ChatUtils.sendMessage(fragTarget, "&aYour Relic Fragment balance was set to &e" + amount + "&a.");
                } else {
                    ChatUtils.sendMessage(player, "&cUsage: /rsc fragments <player> <add|remove|set> <amount>");
                }
                break;

            case "menu":
            default:
                CoreMenu.open(player);
                break;
        }

        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.add("menu");
            completions.add("fragments");
            if (sender.hasPermission(plugin.getConfigManager().getPermissionAdmin())) {
                completions.add("reload");
                completions.add("give");
                completions.add("event");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                completions.add(p.getName());
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (Relic r : plugin.getRelicManager().getRelics()) {
                completions.add(r.getId());
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("event")) {
            completions.add("start");
            completions.add("stop");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("fragments")) {
            if (sender.hasPermission(plugin.getConfigManager().getPermissionAdmin())) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    completions.add(p.getName());
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("fragments")) {
            if (sender.hasPermission(plugin.getConfigManager().getPermissionAdmin())) {
                completions.add("add");
                completions.add("remove");
                completions.add("set");
            }
        }
        return completions;
    }
}
