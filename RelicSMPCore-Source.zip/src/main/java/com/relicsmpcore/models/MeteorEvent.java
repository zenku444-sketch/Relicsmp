package com.relicsmpcore.models;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.Random;

public final class MeteorEvent {

    private final RelicSMPCore plugin;
    private final Random random = new Random();
    private Location crashLocation;
    private boolean landed = false;
    private BukkitTask countdownTask;
    private int countdownSeconds = 30; // Seconds until landing

    public MeteorEvent(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public boolean start() {
        World world = Bukkit.getWorlds().get(0); // Overworld
        if (world == null) return false;

        int minDistance = plugin.getConfig().getInt("meteor.min-distance", 500);
        int maxDistance = plugin.getConfig().getInt("meteor.max-distance", 5000);

        // Pick safe location
        this.crashLocation = findSafeLocation(world, minDistance, maxDistance);
        if (this.crashLocation == null) {
            plugin.getLogger().warning("Could not find a safe overworld location for Meteor!");
            return false;
        }

        // Broadcast spotting
        String coordsStr = "§eX: " + crashLocation.getBlockX() + ", Y: " + crashLocation.getBlockY() + ", Z: " + crashLocation.getBlockZ();
        ChatUtils.broadcast("&8&m========================================");
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&c&lMETEOR EVENT STARTED!");
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&fA cosmic meteor is falling from the skies!");
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&fLanding coordinates: " + coordsStr);
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&fEstimated impact in: &e" + countdownSeconds + " seconds");
        ChatUtils.broadcast("&8&m========================================");

        // Start countdown ticking
        startCountdown();
        return true;
    }

    private void startCountdown() {
        this.countdownTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (countdownSeconds <= 0) {
                    land();
                    cancel();
                    return;
                }

                // Spawning atmospheric trail
                World world = crashLocation.getWorld();
                if (world != null) {
                    double height = crashLocation.getY() + (countdownSeconds * 1.5);
                    Location trailLoc = new Location(world, crashLocation.getX(), height, crashLocation.getZ());
                    world.spawnParticle(org.bukkit.Particle.FLAME, trailLoc, 15, 0.5, 0.5, 0.5, 0.05);
                    world.spawnParticle(org.bukkit.Particle.SMOKE, trailLoc, 20, 0.5, 0.5, 0.5, 0.01);
                    
                    // Visual landing zone ring
                    for (int i = 0; i < 360; i += 30) {
                        double rad = Math.toRadians(i);
                        double px = crashLocation.getX() + Math.cos(rad) * 3.0;
                        double pz = crashLocation.getZ() + Math.sin(rad) * 3.0;
                        Location ringLoc = new Location(world, px, crashLocation.getY() + 0.5, pz);
                        world.spawnParticle(org.bukkit.Particle.FLAME, ringLoc, 2, 0.0, 0.1, 0.0, 0.01);
                    }
                }

                if (countdownSeconds == 15 || countdownSeconds == 10 || countdownSeconds <= 5) {
                    ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&fMeteor impact in &c" + countdownSeconds + " seconds &f!");
                }

                countdownSeconds--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void land() {
        this.landed = true;
        World world = crashLocation.getWorld();
        if (world == null) return;

        int x = crashLocation.getBlockX();
        int y = crashLocation.getBlockY();
        int z = crashLocation.getBlockZ();

        // 1. Crater visual block modifications
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (dx * dx + dy * dy + dz * dz <= 10) {
                        Block b = world.getBlockAt(x + dx, y + dy, z + dz);
                        if (dy < 0) {
                            b.setType(random.nextBoolean() ? Material.OBSIDIAN : Material.MAGMA_BLOCK);
                        } else if (dy == 0) {
                            if (dx == 0 && dz == 0) {
                                // Center chest slot
                            } else {
                                b.setType(random.nextBoolean() ? Material.NETHERRACK : Material.CRYING_OBSIDIAN);
                            }
                        } else {
                            b.setType(Material.AIR);
                        }
                    }
                }
            }
        }

        // 2. Spawn Reward Chest
        Block chestBlock = world.getBlockAt(x, y, z);
        chestBlock.setType(Material.CHEST);
        if (chestBlock.getState() instanceof Chest) {
            Chest chest = (Chest) chestBlock.getState();
            plugin.getMeteorLootManager().populateChest(chest.getInventory());
        }

        // 3. Sound and Particle explosions
        world.playSound(crashLocation, org.bukkit.Sound.ENTITY_GENERIC_EXPLODE, 3.0f, 0.8f);
        world.playSound(crashLocation, org.bukkit.Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 3.0f, 0.7f);
        world.spawnParticle(org.bukkit.Particle.EXPLOSION_EMITTER, crashLocation, 5, 1.0, 1.0, 1.0, 0.2);
        world.spawnParticle(org.bukkit.Particle.LAVA, crashLocation, 40, 2.0, 2.0, 2.0, 0.1);

        ChatUtils.broadcast("&8&m========================================");
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&c&lTHE METEOR HAS IMPACTED!");
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&fGo to coordinates &6X: " + x + ", Y: " + y + ", Z: " + z + " &fto claim the cosmic loot chest!");
        ChatUtils.broadcast("&8&m========================================");
    }

    public void end() {
        if (countdownTask != null) {
            countdownTask.cancel();
        }
        ChatUtils.broadcast(plugin.getConfigManager().getPrefix() + "&7The Meteor Event has concluded.");
    }

    private Location findSafeLocation(World world, int min, int max) {
        for (int attempt = 0; attempt < 50; attempt++) {
            double angle = random.nextDouble() * 2 * Math.PI;
            double dist = min + random.nextDouble() * (max - min);
            int x = (int) (dist * Math.cos(angle));
            int z = (int) (dist * Math.sin(angle));
            
            Block highest = world.getHighestBlockAt(x, z);
            Material type = highest.getType();
            
            if (type != Material.WATER && type != Material.LAVA && type != Material.AIR) {
                return highest.getLocation().add(0, 1, 0); // 1 block above surface
            }
        }
        return world.getSpawnLocation();
    }

    public Location getCrashLocation() {
        return crashLocation;
    }

    public boolean isLanded() {
        return landed;
    }
}
