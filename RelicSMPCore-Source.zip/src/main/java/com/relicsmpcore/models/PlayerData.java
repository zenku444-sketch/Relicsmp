package com.relicsmpcore.models;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class PlayerData {

    private final UUID uuid;
    private final List<String> ownedRelics = new ArrayList<>();
    private final List<String> activityLogs = new ArrayList<>();
    private int eventParticipations = 0;

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() {
        return uuid;
    }

    public List<String> getOwnedRelics() {
        return ownedRelics;
    }

    public List<String> getActivityLogs() {
        return activityLogs;
    }

    public int getEventParticipations() {
        return eventParticipations;
    }

    public void incrementEventParticipation() {
        this.eventParticipations++;
    }

    public void logActivity(String action) {
        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
        activityLogs.add(timestamp + " - " + action);
    }
}
