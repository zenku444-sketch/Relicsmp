package com.relicsmpcore.models;

import org.bukkit.Material;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class Relic {

    private final String id;
    private final String name;
    private final Material material;
    private final int cooldown;
    private final String ability;
    private final List<String> lore;
    
    private UUID currentHolder;
    private List<String> ownershipHistory = new ArrayList<>();

    public Relic(String id, String name, Material material, int cooldown, String ability, List<String> lore) {
        this.id = id;
        this.name = name;
        this.material = material;
        this.cooldown = cooldown;
        this.ability = ability;
        this.lore = lore;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Material getMaterial() {
        return material;
    }

    public int getCooldown() {
        return cooldown;
    }

    public String getAbility() {
        return ability;
    }

    public List<String> getLore() {
        return lore;
    }

    public UUID getCurrentHolder() {
        return currentHolder;
    }

    public void setCurrentHolder(UUID currentHolder) {
        this.currentHolder = currentHolder;
    }

    public List<String> getOwnershipHistory() {
        return ownershipHistory;
    }

    public void setOwnershipHistory(List<String> ownershipHistory) {
        this.ownershipHistory = ownershipHistory;
    }

    public void addHistoryEntry(String entry) {
        if (ownershipHistory == null) {
            ownershipHistory = new ArrayList<>();
        }
        ownershipHistory.add(entry);
    }
}
