package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.Relic;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public final class RelicManager {

    private final RelicSMPCore plugin;
    private final Map<String, Relic> relicsMap = new HashMap<>();
    private final Map<UUID, Map<String, Long>> cooldownsMap = new HashMap<>();

    public RelicManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void loadRelics() {
        this.relicsMap.clear();
        FileConfiguration config = plugin.getConfig();
        ConfigurationSection relicsSection = config.getConfigurationSection("relics");

        if (relicsSection == null) {
            plugin.getLogger().warning("No relics section found in config.yml! Re-creating default configuration...");
            return;
        }

        for (String key : relicsSection.getKeys(false)) {
            ConfigurationSection sec = relicsSection.getConfigurationSection(key);
            if (sec == null) continue;

            String name = sec.getString("name", "&cUnnamed Relic");
            String matName = sec.getString("material", "STONE");
            Material material = Material.matchMaterial(matName);
            if (material == null) {
                material = Material.STONE;
                plugin.getLogger().warning("Invalid material '" + matName + "' specified for relic '" + key + "'. Defaulting to STONE.");
            }

            int cooldown = sec.getInt("cooldown", 30);
            String ability = sec.getString("ability", "None");
            List<String> lore = sec.getStringList("lore");

            Relic relic = new Relic(key, name, material, cooldown, ability, lore);

            // Restore holder and history from relics.yml if available
            FileConfiguration relicsData = plugin.getDataManager().getRelicsData();
            if (relicsData.contains(key + ".holder")) {
                String holderStr = relicsData.getString(key + ".holder");
                if (holderStr != null && !holderStr.isEmpty()) {
                    relic.setCurrentHolder(UUID.fromString(holderStr));
                }
            }
            if (relicsData.contains(key + ".history")) {
                List<String> historyList = relicsData.getStringList(key + ".history");
                relic.setOwnershipHistory(new ArrayList<>(historyList));
            }

            relicsMap.put(key.toLowerCase(), relic);
        }
        plugin.getLogger().info("Loaded " + relicsMap.size() + " custom relics from config.");
    }

    public void saveRelics() {
        FileConfiguration relicsData = plugin.getDataManager().getRelicsData();
        for (Relic relic : relicsMap.values()) {
            relicsData.set(relic.getId() + ".holder", relic.getCurrentHolder() != null ? relic.getCurrentHolder().toString() : "");
            relicsData.set(relic.getId() + ".history", relic.getOwnershipHistory());
        }
    }

    public Collection<Relic> getRelics() {
        return relicsMap.values();
    }

    public Relic getRelic(String id) {
        return relicsMap.get(id.toLowerCase());
    }

    public boolean hasCooldown(Player player, String relicId) {
        if (!cooldownsMap.containsKey(player.getUniqueId())) return false;
        Map<String, Long> playerCooldowns = cooldownsMap.get(player.getUniqueId());
        if (!playerCooldowns.containsKey(relicId)) return false;

        long expTime = playerCooldowns.get(relicId);
        return System.currentTimeMillis() < expTime;
    }

    public long getCooldownRemaining(Player player, String relicId) {
        if (!hasCooldown(player, relicId)) return 0;
        return (cooldownsMap.get(player.getUniqueId()).get(relicId) - System.currentTimeMillis()) / 1000;
    }

    public void setCooldown(Player player, String relicId, int seconds) {
        Map<String, Long> playerCooldowns = cooldownsMap.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
        playerCooldowns.put(relicId, System.currentTimeMillis() + (seconds * 1000L));
    }

    public void transferOwnership(String relicId, UUID newOwnerUuid) {
        Relic relic = getRelic(relicId);
        if (relic == null) return;

        relic.setCurrentHolder(newOwnerUuid);
        String name = Bukkit.getOfflinePlayer(newOwnerUuid).getName();
        if (name == null) name = "Unknown Player";

        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        relic.addHistoryEntry(timestamp + " - " + name + " (" + newOwnerUuid.toString() + ")");
    }

    public ItemStack createRelicItemStack(Relic relic) {
        ItemStack item = new ItemStack(relic.getMaterial());
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', relic.getName()));
        
        List<String> coloredLore = new ArrayList<>();
        for (String line : relic.getLore()) {
            String processed = line.replace("%cooldown%", String.valueOf(relic.getCooldown()));
            coloredLore.add(org.bukkit.ChatColor.translateAlternateColorCodes('&', processed));
        }
        
        // Add current holder line dynamically
        coloredLore.add("");
        if (relic.getCurrentHolder() != null) {
            String holderName = Bukkit.getOfflinePlayer(relic.getCurrentHolder()).getName();
            coloredLore.add(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&7Current Holder: &e" + (holderName != null ? holderName : "Unknown")));
        } else {
            coloredLore.add(org.bukkit.ChatColor.translateAlternateColorCodes('&', "&7Current Holder: &7None"));
        }

        meta.setLore(coloredLore);
        // Make it glowing
        meta.addEnchant(org.bukkit.enchantments.Enchantment.UNBREAKING, 1, true);
        meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        
        item.setItemMeta(meta);
        return item;
    }
}
