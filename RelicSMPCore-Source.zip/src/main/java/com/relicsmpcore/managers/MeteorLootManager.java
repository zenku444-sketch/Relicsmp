package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.enchantments.Enchantment;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class MeteorLootManager {
    private final RelicSMPCore plugin;
    private final Random random = new Random();

    public MeteorLootManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void populateChest(Inventory chestInventory) {
        chestInventory.clear();
        int size = chestInventory.getSize();

        List<ItemStack> items = generateLoot();
        for (ItemStack item : items) {
            int slot = random.nextInt(size);
            int attempts = 0;
            while (chestInventory.getItem(slot) != null && attempts < 50) {
                slot = random.nextInt(size);
                attempts++;
            }
            chestInventory.setItem(slot, item);
        }
    }

    private List<ItemStack> generateLoot() {
        List<ItemStack> loot = new ArrayList<>();

        // Diamonds (80% chance)
        if (random.nextDouble() < 0.80) {
            int amt = 2 + random.nextInt(5); // 2-6
            loot.add(new ItemStack(Material.DIAMOND, amt));
        }

        // Netherite scraps (50% chance)
        if (random.nextDouble() < 0.50) {
            int amt = 1 + random.nextInt(3); // 1-3
            loot.add(new ItemStack(Material.NETHERITE_SCRAP, amt));
        }

        // Golden apples (60% chance)
        if (random.nextDouble() < 0.60) {
            int amt = 1 + random.nextInt(4); // 1-4
            loot.add(new ItemStack(Material.GOLDEN_APPLE, amt));
        }

        // Enchanted Books (40% chance)
        if (random.nextDouble() < 0.40) {
            ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
            EnchantmentStorageMeta meta = (EnchantmentStorageMeta) book.getItemMeta();
            if (meta != null) {
                Enchantment[] enchants = {
                    Enchantment.SHARPNESS,
                    Enchantment.PROTECTION,
                    Enchantment.MENDING,
                    Enchantment.UNBREAKING,
                    Enchantment.FORTUNE,
                    Enchantment.FEATHER_FALLING
                };
                Enchantment randomEnchant = enchants[random.nextInt(enchants.length)];
                meta.addStoredEnchant(randomEnchant, randomEnchant.getMaxLevel(), true);
                book.setItemMeta(meta);
            }
            loot.add(book);
        }

        // Relic Fragments (Configurable)
        if (plugin.getConfig().getBoolean("fragments.enabled", true)) {
            int minDrop = plugin.getConfig().getInt("fragments.min-drop", 1);
            int maxDrop = plugin.getConfig().getInt("fragments.max-drop", 5);
            int dropAmt = minDrop;
            if (maxDrop > minDrop) {
                dropAmt = minDrop + random.nextInt(maxDrop - minDrop + 1);
            }
            loot.add(createFragmentItemStack(dropAmt));
        }

        return loot;
    }

    public ItemStack createFragmentItemStack(int amount) {
        ItemStack frag = new ItemStack(Material.PRISMARINE_SHARD, amount);
        ItemMeta meta = frag.getItemMeta();
        if (meta != null) {
            meta.setDisplayName("§b§lRelic Fragment");
            List<String> lore = new ArrayList<>();
            lore.add("§7An ancient shard glowing with relic energy.");
            lore.add("§7Recovered from a crashed cosmic meteor.");
            lore.add("");
            lore.add("§e▶ Right-click to redeem into your fragment balance!");
            meta.setLore(lore);
            frag.setItemMeta(meta);
        }
        return frag;
    }
}
