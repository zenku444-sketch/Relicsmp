package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public final class DataManager {

    private final RelicSMPCore plugin;
    
    private File relicsFile;
    private FileConfiguration relicsConfig;

    private File playersFile;
    private FileConfiguration playersConfig;

    public DataManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void setup() {
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }

        relicsFile = new File(plugin.getDataFolder(), "relics.yml");
        if (!relicsFile.exists()) {
            try {
                relicsFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create relics.yml storage file!");
            }
        }
        relicsConfig = YamlConfiguration.loadConfiguration(relicsFile);

        playersFile = new File(plugin.getDataFolder(), "players.yml");
        if (!playersFile.exists()) {
            try {
                playersFile.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().severe("Could not create players.yml storage file!");
            }
        }
        playersConfig = YamlConfiguration.loadConfiguration(playersFile);
    }

    public FileConfiguration getRelicsData() {
        return relicsConfig;
    }

    public FileConfiguration getPlayersData() {
        return playersConfig;
    }

    public void saveRelicsData() {
        try {
            relicsConfig.save(relicsFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save to relics.yml!");
        }
    }

    public void savePlayersData() {
        try {
            playersConfig.save(playersFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save to players.yml!");
        }
    }

    public void reloadConfigs() {
        relicsConfig = YamlConfiguration.loadConfiguration(relicsFile);
        playersConfig = YamlConfiguration.loadConfiguration(playersFile);
    }
}
