package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.MeteorEvent;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.Random;

public final class EventManager {

    private final RelicSMPCore plugin;
    private final Random random = new Random();
    private BukkitTask scheduledTask;
    private boolean active = false;
    private String currentEventName = "None";
    
    private MeteorEvent activeMeteorEvent;
    private long nextEventScheduledTime = 0;

    public EventManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void startScheduler() {
        if (scheduledTask != null) {
            scheduledTask.cancel();
        }

        long intervalMinutes = plugin.getConfig().getInt("meteor.interval", 3600) / 60;
        long intervalTicks = intervalMinutes * 1200L;
        
        this.nextEventScheduledTime = System.currentTimeMillis() + (intervalMinutes * 60 * 1000L);

        scheduledTask = Bukkit.getScheduler().runTaskTimer(plugin, this::triggerRandomEvent, intervalTicks, intervalTicks);
        plugin.getLogger().info("Event system scheduler running. Next random event in " + intervalMinutes + " minutes.");
    }

    public void stopScheduler() {
        if (scheduledTask != null) {
            scheduledTask.cancel();
            scheduledTask = null;
        }
    }

    public void restartScheduler() {
        stopScheduler();
        startScheduler();
    }

    public void triggerRandomEvent() {
        long intervalMinutes = plugin.getConfig().getInt("meteor.interval", 3600) / 60;
        this.nextEventScheduledTime = System.currentTimeMillis() + (intervalMinutes * 60 * 1000L);

        // 50% chance to start a Meteor Event, 50% chance to start a standard chat event
        if (random.nextBoolean()) {
            startMeteorEvent();
        } else {
            String[] events = {"Celestial Storm", "Abyssal Rift", "Winds of Chaos", "Titan's Awakening", "Golden Overload"};
            String chosenEvent = events[random.nextInt(events.length)];
            startEvent(chosenEvent);
        }
    }

    public void startEvent(String name) {
        if (active) {
            endEvent();
        }
        this.active = true;
        this.currentEventName = name;
        this.activeMeteorEvent = null;
        
        String prefix = plugin.getConfigManager().getPrefix();
        ChatUtils.broadcast("&8&m========================================");
        ChatUtils.broadcast(prefix + "&6&lSERVER-WIDE EVENT STARTED!");
        ChatUtils.broadcast(prefix + "&fEvent Name: &e&l" + name);
        ChatUtils.broadcast(prefix + "&fDuration: &b10 Minutes");
        ChatUtils.broadcast(prefix + "&7Compete with other players to secure rewards!");
        ChatUtils.broadcast("&8&m========================================");

        // Schedule event end in 10 minutes (12000 ticks)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (isActive() && currentEventName.equals(name)) {
                endEvent();
            }
        }, 12000L);
    }

    public void startMeteorEvent() {
        if (active) {
            endEvent();
        }
        
        MeteorEvent meteor = new MeteorEvent(plugin);
        if (meteor.start()) {
            this.active = true;
            this.currentEventName = "Meteor Crash";
            this.activeMeteorEvent = meteor;

            long durationSeconds = plugin.getConfig().getInt("meteor.duration", 900);
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (isActive() && activeMeteorEvent == meteor) {
                    endEvent();
                }
            }, durationSeconds * 20L);
        }
    }

    public void endEvent() {
        if (!active) return;
        
        if (activeMeteorEvent != null) {
            activeMeteorEvent.end();
            activeMeteorEvent = null;
        } else {
            String prefix = plugin.getConfigManager().getPrefix();
            ChatUtils.broadcast("&8&m========================================");
            ChatUtils.broadcast(prefix + "&6&lEVENT OVER: &e&l" + currentEventName);
            ChatUtils.broadcast(prefix + "&fRewards are being distributed to online players!");
            ChatUtils.broadcast("&8&m========================================");

            distributeRewards();
        }

        this.active = false;
        this.currentEventName = "None";
    }

    private void distributeRewards() {
        List<String> rewards = plugin.getConfigManager().getRewards();
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (String rewardCommand : rewards) {
                String cmd = rewardCommand
                        .replace("%player%", player.getName())
                        .replace("&", "§");
                
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            }
        }
    }

    public boolean isActive() {
        return active;
    }

    public String getCurrentEventName() {
        return currentEventName;
    }

    public MeteorEvent getActiveMeteorEvent() {
        return activeMeteorEvent;
    }

    public long getNextEventRemainingSeconds() {
        long remaining = (nextEventScheduledTime - System.currentTimeMillis()) / 1000;
        return Math.max(0, remaining);
    }
}
