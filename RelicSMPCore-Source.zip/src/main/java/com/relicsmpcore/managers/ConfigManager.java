package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.List;

public final class ConfigManager {

    private final RelicSMPCore plugin;
    private int saveIntervalMinutes;
    private String prefix;
    private String permissionUse;
    private String permissionAdmin;
    private int eventIntervalMinutes;
    private boolean broadcastsEnabled;
    private List<String> rewards;

    public ConfigManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void load() {
        FileConfiguration config = plugin.getConfig();

        this.saveIntervalMinutes = config.getInt("settings.save-interval-minutes", 5);
        this.prefix = config.getString("settings.prefix", "&e&lRelicSMP &8» &f");
        this.permissionUse = config.getString("settings.permission-use", "relicsmpcore.use");
        this.permissionAdmin = config.getString("settings.permission-admin", "relicsmpcore.admin");

        this.eventIntervalMinutes = config.getInt("events.interval-minutes", 60);
        this.broadcastsEnabled = config.getBoolean("events.broadcasts-enabled", true);
        this.rewards = config.getStringList("events.rewards");
    }

    public int getSaveIntervalMinutes() {
        return saveIntervalMinutes;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getPermissionUse() {
        return permissionUse;
    }

    public String getPermissionAdmin() {
        return permissionAdmin;
    }

    public int getEventIntervalMinutes() {
        return eventIntervalMinutes;
    }

    public boolean isBroadcastsEnabled() {
        return broadcastsEnabled;
    }

    public List<String> getRewards() {
        return rewards;
    }
}
