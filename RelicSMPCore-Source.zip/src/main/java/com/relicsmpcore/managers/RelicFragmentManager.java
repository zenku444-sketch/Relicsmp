package com.relicsmpcore.managers;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class RelicFragmentManager {
    private final RelicSMPCore plugin;
    private final Map<UUID, Integer> fragmentBalances = new HashMap<>();

    public RelicFragmentManager(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    public void loadBalances() {
        FileConfiguration playersData = plugin.getDataManager().getPlayersData();
        if (playersData == null || playersData.getConfigurationSection("players") == null) return;
        for (String key : playersData.getConfigurationSection("players").getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                int fragments = playersData.getInt("players." + key + ".fragments", 0);
                fragmentBalances.put(uuid, fragments);
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void saveBalances() {
        FileConfiguration playersData = plugin.getDataManager().getPlayersData();
        if (playersData == null) return;
        for (Map.Entry<UUID, Integer> entry : fragmentBalances.entrySet()) {
            playersData.set("players." + entry.getKey().toString() + ".fragments", entry.getValue());
        }
        plugin.getDataManager().savePlayersData();
    }

    public int getFragments(UUID uuid) {
        return fragmentBalances.getOrDefault(uuid, 0);
    }

    public void addFragments(UUID uuid, int amount) {
        setFragments(uuid, getFragments(uuid) + amount);
    }

    public boolean removeFragments(UUID uuid, int amount) {
        int current = getFragments(uuid);
        if (current < amount) return false;
        setFragments(uuid, current - amount);
        return true;
    }

    public void setFragments(UUID uuid, int amount) {
        fragmentBalances.put(uuid, Math.max(0, amount));
        FileConfiguration playersData = plugin.getDataManager().getPlayersData();
        if (playersData != null) {
            playersData.set("players." + uuid.toString() + ".fragments", Math.max(0, amount));
            plugin.getDataManager().savePlayersData();
        }
    }
}
