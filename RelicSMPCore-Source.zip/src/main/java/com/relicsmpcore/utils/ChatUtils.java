package com.relicsmpcore.utils;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public final class ChatUtils {

    private static RelicSMPCore plugin;

    public static void init(RelicSMPCore mainInstance) {
        plugin = mainInstance;
    }

    public static String color(String message) {
        if (message == null) return "";
        
        // Translate hex colors: &#FFFFFF -> ChatColor
        // Modern Paper supports MiniMessage, but standard ChatColor translate alternate color codes is compatible
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public static void sendMessage(Player player, String message) {
        String prefix = plugin != null ? plugin.getConfigManager().getPrefix() : "";
        player.sendMessage(color(prefix + message));
    }

    public static void broadcast(String message) {
        Bukkit.broadcastMessage(color(message));
    }
}
