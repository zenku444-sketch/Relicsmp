package com.relicsmpcore.gui;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class SettingsMenu {

    public static final String TITLE = "§6§lSMP Configurations";

    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        RelicSMPCore plugin = RelicSMPCore.getInstance();

        // Border fills
        ItemStack borderGlass = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        ItemMeta borderMeta = borderGlass.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            borderGlass.setItemMeta(borderMeta);
        }
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i > 17 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderGlass);
            }
        }

        // Save Interval Option Display
        ItemStack saveItem = new ItemStack(Material.COMPASS);
        ItemMeta saveMeta = saveItem.getItemMeta();
        if (saveMeta != null) {
            saveMeta.setDisplayName("§6§l📁 Safe Auto-Save Timer 📁");
            List<String> lore = new ArrayList<>();
            lore.add("§7Frequency parameter for database flushes.");
            lore.add("§7Interval: §f" + plugin.getConfigManager().getSaveIntervalMinutes() + " Minutes");
            lore.add("");
            lore.add("§e🔧 Configure via config.yml");
            saveMeta.setLore(lore);
            saveItem.setItemMeta(saveMeta);
        }
        inv.setItem(11, saveItem);

        // Chat Prefix Display
        ItemStack prefixItem = new ItemStack(Material.NAME_TAG);
        ItemMeta prefixMeta = prefixItem.getItemMeta();
        if (prefixMeta != null) {
            prefixMeta.setDisplayName("§e§l💬 Chat Prefix Marker 💬");
            List<String> lore = new ArrayList<>();
            lore.add("§7Custom display prefix prepended to system chats.");
            lore.add("§7Prefix: §r" + plugin.getConfigManager().getPrefix());
            lore.add("");
            lore.add("§e🔧 Configure via config.yml");
            prefixMeta.setLore(lore);
            prefixItem.setItemMeta(prefixMeta);
        }
        inv.setItem(13, prefixItem);

        // Permissions Display
        ItemStack permItem = new ItemStack(Material.IRON_DOOR);
        ItemMeta permMeta = permItem.getItemMeta();
        if (permMeta != null) {
            permMeta.setDisplayName("§3§l🛡 Security Nodes 🛡");
            List<String> lore = new ArrayList<>();
            lore.add("§7Standard Spigot permission checks loaded:");
            lore.add("§7Use: §f" + plugin.getConfigManager().getPermissionUse());
            lore.add("§7Admin: §f" + plugin.getConfigManager().getPermissionAdmin());
            permMeta.setLore(lore);
            permItem.setItemMeta(permMeta);
        }
        inv.setItem(15, permItem);

        // Back button
        ItemStack backBtn = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backBtn.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§c§l◀ Return to Main Menu");
            backBtn.setItemMeta(backMeta);
        }
        inv.setItem(22, backBtn);

        player.openInventory(inv);
    }
}
