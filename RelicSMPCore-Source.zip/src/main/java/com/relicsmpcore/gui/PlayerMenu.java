package com.relicsmpcore.gui;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.Relic;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class PlayerMenu {

    public static final String TITLE = "§a§lRelic Owner Tracking";

    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        RelicSMPCore plugin = RelicSMPCore.getInstance();

        // Borders
        ItemStack borderGlass = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta borderMeta = borderGlass.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            borderGlass.setItemMeta(borderMeta);
        }
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i > 17 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderGlass);
            }
        }

        // Loop over the 5 loaded relics and display their owners
        int index = 11;
        for (Relic r : plugin.getRelicManager().getRelics()) {
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            ItemMeta headMeta = head.getItemMeta();
            if (headMeta != null) {
                headMeta.setDisplayName("§d" + r.getName() + " §7Tracking");
                List<String> lore = new ArrayList<>();
                
                if (r.getCurrentHolder() != null) {
                    OfflinePlayer holder = Bukkit.getOfflinePlayer(r.getCurrentHolder());
                    lore.add("§7Holder Name: §e" + (holder.getName() != null ? holder.getName() : "Unknown"));
                    lore.add("§7Holder UUID: §f" + r.getCurrentHolder().toString());
                    lore.add("§7State: §aActive Possession");
                } else {
                    lore.add("§7Holder: §cUnowned/Lost");
                }
                
                lore.add("");
                lore.add("§fOwnership Chronicle:");
                if (r.getOwnershipHistory().isEmpty()) {
                    lore.add("§8- No recorded claims.");
                } else {
                    // Show last 3 histories to avoid inventory lore bloat
                    List<String> hist = r.getOwnershipHistory();
                    int start = Math.max(0, hist.size() - 3);
                    for (int k = start; k < hist.size(); k++) {
                        lore.add("§e" + hist.get(k));
                    }
                }

                headMeta.setLore(lore);
                head.setItemMeta(headMeta);
            }
            inv.setItem(index++, head);
            if (index == 16) break;
        }

        // Back button
        ItemStack backBtn = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backBtn.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§c§l◀ Return to Main Menu");
            backBtn.setItemMeta(backMeta);
        }
        inv.setItem(22, backBtn);

        player.openInventory(inv);
    }
}
