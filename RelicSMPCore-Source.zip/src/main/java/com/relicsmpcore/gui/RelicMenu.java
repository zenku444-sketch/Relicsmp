package com.relicsmpcore.gui;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.Relic;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class RelicMenu {

    public static final String TITLE = "§e§lSMP Relics Directory";

    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        // Fill glass borders
        ItemStack borderGlass = new ItemStack(Material.CYAN_STAINED_GLASS_PANE);
        ItemMeta borderMeta = borderGlass.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            borderGlass.setItemMeta(borderMeta);
        }
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i > 17 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderGlass);
            }
        }

        // Add back button at bottom center (slot 22)
        ItemStack backBtn = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backBtn.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§c§l◀ Return to Main Menu");
            List<String> backLore = new ArrayList<>();
            backLore.add("§7Click to jump back to main");
            backLore.add("§7dashboard layout console.");
            backMeta.setLore(backLore);
            backBtn.setItemMeta(backMeta);
        }
        inv.setItem(22, backBtn);

        // Populate Relics in central slots
        RelicSMPCore plugin = RelicSMPCore.getInstance();
        int slot = 11;
        for (Relic relic : plugin.getRelicManager().getRelics()) {
            ItemStack relicItem = plugin.getRelicManager().createRelicItemStack(relic);
            
            // Add custom click lore for admin triggers
            ItemMeta meta = relicItem.getItemMeta();
            if (meta != null) {
                List<String> lore = meta.getLore();
                if (lore == null) lore = new ArrayList<>();
                lore.add("");
                if (player.hasPermission("relicsmpcore.admin")) {
                    lore.add("§e▶ Shift-Click to grant yourself this relic!");
                }
                meta.setLore(lore);
                relicItem.setItemMeta(meta);
            }
            
            inv.setItem(slot++, relicItem);
            
            // Skip middle column spaces if needed
            if (slot == 16) {
                break;
            }
        }

        player.openInventory(inv);
    }
}
