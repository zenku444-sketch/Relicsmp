package com.relicsmpcore.gui;

import com.relicsmpcore.RelicSMPCore;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class CoreMenu {

    public static final String TITLE = "§e§lRelic SMP Core";

    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);

        // Border pane items
        ItemStack borderGlass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta borderMeta = borderGlass.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            borderGlass.setItemMeta(borderMeta);
        }

        for (int i = 0; i < 27; i++) {
            if (i < 9 || i > 17 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderGlass);
            }
        }

        // 1. Relics GUI Button
        ItemStack relicsBtn = new ItemStack(Material.NETHER_STAR);
        ItemMeta relicsMeta = relicsBtn.getItemMeta();
        if (relicsMeta != null) {
            relicsMeta.setDisplayName("§b§l⚡ Relics Catalog ⚡");
            List<String> lore = new ArrayList<>();
            lore.add("§7View all custom artifacts, abilities,");
            lore.add("§7cooldown timers, and current holder tracking.");
            lore.add("");
            lore.add("§e▶ Click to browse relics!");
            relicsMeta.setLore(lore);
            relicsBtn.setItemMeta(relicsMeta);
        }
        inv.setItem(10, relicsBtn);

        // 2. Events GUI Button
        ItemStack eventsBtn = new ItemStack(Material.CLOCK);
        ItemMeta eventsMeta = eventsBtn.getItemMeta();
        if (eventsMeta != null) {
            eventsMeta.setDisplayName("§d§l⏳ Server Events ⏳");
            List<String> lore = new ArrayList<>();
            lore.add("§7Check active scheduler details,");
            lore.add("§7rewards, force-starts, and warnings.");
            lore.add("");
            lore.add("§e▶ Click to manage events!");
            eventsMeta.setLore(lore);
            eventsBtn.setItemMeta(eventsMeta);
        }
        inv.setItem(12, eventsBtn);

        // 3. Players Stats Button
        ItemStack playersBtn = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta playersMeta = playersBtn.getItemMeta();
        if (playersMeta != null) {
            playersMeta.setDisplayName("§a§l👥 Player Database 👥");
            List<String> lore = new ArrayList<>();
            lore.add("§7Inspect player statistics, event counts,");
            lore.add("§7relic histories, and activity logs.");
            lore.add("");
            lore.add("§e▶ Click to view database!");
            playersMeta.setLore(lore);
            playersBtn.setItemMeta(playersMeta);
        }
        inv.setItem(14, playersBtn);

        // 4. Settings Button (Redstone Repeater)
        ItemStack settingsBtn = new ItemStack(Material.REPEATER);
        ItemMeta settingsMeta = settingsBtn.getItemMeta();
        if (settingsMeta != null) {
            settingsMeta.setDisplayName("§6§l⚙ Settings ⚙");
            List<String> lore = new ArrayList<>();
            lore.add("§7Adjust core SMP configuration variables,");
            lore.add("§7prefix codes, save intervals, and permissions.");
            lore.add("");
            lore.add("§e▶ Click to edit configurations!");
            settingsMeta.setLore(lore);
            settingsBtn.setItemMeta(settingsMeta);
        }
        inv.setItem(16, settingsBtn);

        // 5. Reload Administrative Button (Barrier)
        ItemStack reloadBtn = new ItemStack(Material.BARRIER);
        ItemMeta reloadMeta = reloadBtn.getItemMeta();
        if (reloadMeta != null) {
            reloadMeta.setDisplayName("§c§l♻ Reload Configurations ♻");
            List<String> lore = new ArrayList<>();
            lore.add("§7Perform structural safe-save and hot-reload");
            lore.add("§7for all internal yaml resources instantly.");
            lore.add("");
            lore.add("§7Permission required: &crelicsmpcore.admin");
            lore.add("");
            lore.add("§c▶ Click to Reload!");
            reloadMeta.setLore(lore);
            reloadBtn.setItemMeta(reloadMeta);
        }
        inv.setItem(22, reloadBtn);

        player.openInventory(inv);
    }
}
