package com.relicsmpcore.gui;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.MeteorEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class EventMenu {

    public static final String TITLE = "§d§lEvent Control Hub";

    public static void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        RelicSMPCore plugin = RelicSMPCore.getInstance();

        // Fill glass borders
        ItemStack borderGlass = new ItemStack(Material.MAGENTA_STAINED_GLASS_PANE);
        ItemMeta borderMeta = borderGlass.getItemMeta();
        if (borderMeta != null) {
            borderMeta.setDisplayName(" ");
            borderGlass.setItemMeta(borderMeta);
        }
        for (int i = 0; i < 27; i++) {
            if (i < 9 || i > 17 || i % 9 == 0 || i % 9 == 8) {
                inv.setItem(i, borderGlass);
            }
        }

        // Slot 10: Event Status Item
        ItemStack statusItem = new ItemStack(plugin.getEventManager().isActive() ? Material.REDSTONE_BLOCK : Material.COAL_BLOCK);
        ItemMeta statusMeta = statusItem.getItemMeta();
        if (statusMeta != null) {
            statusMeta.setDisplayName("§fStatus: " + (plugin.getEventManager().isActive() ? "§a§lACTIVE" : "§c§lDORMANT"));
            List<String> lore = new ArrayList<>();
            lore.add("§7Current Event: §e" + plugin.getEventManager().getCurrentEventName());
            lore.add("§7Broadcast alerts: " + (plugin.getConfig().getBoolean("meteor.broadcast", true) ? "§aEnabled" : "§cDisabled"));
            statusMeta.setLore(lore);
            statusItem.setItemMeta(statusMeta);
        }
        inv.setItem(10, statusItem);

        // Slot 11: Next Event Timer Item
        ItemStack timerItem = new ItemStack(Material.CLOCK);
        ItemMeta timerMeta = timerItem.getItemMeta();
        if (timerMeta != null) {
            timerMeta.setDisplayName("§d§lNext Event Timer");
            List<String> lore = new ArrayList<>();
            long totalSecs = plugin.getEventManager().getNextEventRemainingSeconds();
            long hours = totalSecs / 3600;
            long mins = (totalSecs % 3600) / 60;
            long secs = totalSecs % 60;
            String remainingTimeStr = String.format("%02d:%02d:%02d", hours, mins, secs);

            lore.add("§7Time until next random event:");
            lore.add("  §b" + remainingTimeStr);
            lore.add("");
            lore.add("§7Automatic interval: §f" + (plugin.getConfig().getInt("meteor.interval", 3600) / 60) + " mins");
            timerMeta.setLore(lore);
            timerItem.setItemMeta(timerMeta);
        }
        inv.setItem(11, timerItem);

        // Slot 12: View Active Meteor Event details
        ItemStack meteorItem;
        if (plugin.getEventManager().isActive() && plugin.getEventManager().getCurrentEventName().equalsIgnoreCase("Meteor Crash")) {
            meteorItem = new ItemStack(Material.FIRE_CHARGE);
            ItemMeta meteorMeta = meteorItem.getItemMeta();
            if (meteorMeta != null) {
                meteorMeta.setDisplayName("§e§l☄ Active Meteor Event ☄");
                List<String> lore = new ArrayList<>();
                MeteorEvent meteor = plugin.getEventManager().getActiveMeteorEvent();
                if (meteor != null) {
                    lore.add("§7Status: " + (meteor.isLanded() ? "§a§lLANDED" : "§6§lFALLING"));
                    Location loc = meteor.getCrashLocation();
                    if (loc != null) {
                        lore.add("§7Coordinates:");
                        lore.add("  §7X: §e" + loc.getBlockX());
                        lore.add("  §7Y: §e" + loc.getBlockY());
                        lore.add("  §7Z: §e" + loc.getBlockZ());
                    }
                }
                meteorMeta.setLore(lore);
                meteorItem.setItemMeta(meteorMeta);
            }
        } else {
            meteorItem = new ItemStack(Material.FLINT_AND_STEEL);
            ItemMeta meteorMeta = meteorItem.getItemMeta();
            if (meteorMeta != null) {
                meteorMeta.setDisplayName("§7☄ No Active Meteor Event ☄");
                List<String> lore = new ArrayList<>();
                lore.add("§7No cosmic debris detected in the");
                lore.add("§7atmosphere at this moment.");
                meteorMeta.setLore(lore);
                meteorItem.setItemMeta(meteorMeta);
            }
        }
        inv.setItem(12, meteorItem);

        // Slot 14: Force Start Random Event Item
        ItemStack triggerItem = new ItemStack(Material.FIREWORK_ROCKET);
        ItemMeta triggerMeta = triggerItem.getItemMeta();
        if (triggerMeta != null) {
            triggerMeta.setDisplayName("§a§l⚡ Force Start Random Event ⚡");
            List<String> lore = new ArrayList<>();
            lore.add("§7Instantly triggers one of the custom server events");
            lore.add("§7with global chat broad-alerts and rewards.");
            lore.add("");
            lore.add("§a▶ Click to trigger now!");
            triggerMeta.setLore(lore);
            triggerItem.setItemMeta(triggerMeta);
        }
        inv.setItem(14, triggerItem);

        // Slot 15: Force Start Meteor Event Item
        ItemStack startMeteorItem = new ItemStack(Material.MAGMA_BLOCK);
        ItemMeta startMeteorMeta = startMeteorItem.getItemMeta();
        if (startMeteorMeta != null) {
            startMeteorMeta.setDisplayName("§e§l☄ Force Start Meteor Event ☄");
            List<String> lore = new ArrayList<>();
            lore.add("§7Instantly triggers a meteor crash in the");
            lore.add("§7overworld with crater generation and rewards.");
            lore.add("");
            lore.add("§e▶ Click to trigger meteor crash!");
            startMeteorMeta.setLore(lore);
            startMeteorItem.setItemMeta(startMeteorMeta);
        }
        inv.setItem(15, startMeteorItem);

        // Slot 16: Force Stop Event Item
        ItemStack stopItem = new ItemStack(Material.RED_DYE);
        ItemMeta stopMeta = stopItem.getItemMeta();
        if (stopMeta != null) {
            stopMeta.setDisplayName("§c§l⏹ Force End Active Event ⏹");
            List<String> lore = new ArrayList<>();
            lore.add("§7Immediately concludes the current event run,");
            lore.add("§7cleaning up active systems or distributing rewards.");
            lore.add("");
            lore.add("§c▶ Click to cancel event!");
            stopMeta.setLore(lore);
            stopItem.setItemMeta(stopMeta);
        }
        inv.setItem(16, stopItem);

        // Slot 22: Return to Main Menu Back button
        ItemStack backBtn = new ItemStack(Material.ARROW);
        ItemMeta backMeta = backBtn.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName("§c§l◀ Return to Main Menu");
            backBtn.setItemMeta(backMeta);
        }
        inv.setItem(22, backBtn);

        player.openInventory(inv);
    }
}
