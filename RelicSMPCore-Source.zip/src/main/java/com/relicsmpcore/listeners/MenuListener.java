package com.relicsmpcore.listeners;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.gui.*;
import com.relicsmpcore.models.Relic;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class MenuListener implements Listener {

    private final RelicSMPCore plugin;

    public MenuListener(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        String title = event.getView().getTitle();
        if (!(event.getWhoClicked() instanceof Player)) return;

        Player player = (Player) event.getWhoClicked();

        // Check if viewing one of our managed inventories
        boolean isOurGui = title.equals(CoreMenu.TITLE) || 
                           title.equals(RelicMenu.TITLE) || 
                           title.equals(EventMenu.TITLE) || 
                           title.equals(PlayerMenu.TITLE) || 
                           title.equals(SettingsMenu.TITLE);

        if (!isOurGui) return;

        // Freeze GUI interaction items so they cannot be moved or looted
        event.setCancelled(true);

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        // Navigation check (ARROW corresponds to returning to main menu)
        if (clicked.getType() == Material.ARROW) {
            CoreMenu.open(player);
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            return;
        }

        ItemMeta meta = clicked.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;
        String displayName = meta.getDisplayName();

        // 1. MAIN MENU INTERACTIONS
        if (title.equals(CoreMenu.TITLE)) {
            if (displayName.contains("Relics Catalog")) {
                RelicMenu.open(player);
            } else if (displayName.contains("Server Events")) {
                EventMenu.open(player);
            } else if (displayName.contains("Player Database")) {
                PlayerMenu.open(player);
            } else if (displayName.contains("Settings")) {
                SettingsMenu.open(player);
            } else if (displayName.contains("Reload Configurations")) {
                if (player.hasPermission("relicsmpcore.admin")) {
                    plugin.reloadPlugin();
                    ChatUtils.sendMessage(player, "&aPlugin configs hot-reloaded successfully!");
                    player.closeInventory();
                } else {
                    ChatUtils.sendMessage(player, "&cInsufficient permission node.");
                }
            }
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
            return;
        }

        // 2. RELIC MENU - Shift click triggers give for Admins
        if (title.equals(RelicMenu.TITLE)) {
            if (event.getClick() == ClickType.SHIFT_LEFT || event.getClick() == ClickType.SHIFT_RIGHT) {
                if (player.hasPermission("relicsmpcore.admin")) {
                    for (Relic relic : plugin.getRelicManager().getRelics()) {
                        String coloredName = ChatUtils.color(relic.getName());
                        if (displayName.contains(coloredName)) {
                            ItemStack gift = plugin.getRelicManager().createRelicItemStack(relic);
                            player.getInventory().addItem(gift);
                            plugin.getRelicManager().transferOwnership(relic.getId(), player.getUniqueId());
                            ChatUtils.sendMessage(player, "&aIssued yourself: " + relic.getName());
                            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.0f);
                            player.closeInventory();
                            return;
                        }
                    }
                }
            }
        }

        // 3. EVENT MENU Hub controls
        if (title.equals(EventMenu.TITLE)) {
            if (displayName.contains("Force Start Random Event")) {
                if (player.hasPermission("relicsmpcore.admin")) {
                    plugin.getEventManager().triggerRandomEvent();
                    player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.1f);
                    player.closeInventory();
                } else {
                    ChatUtils.sendMessage(player, "&cRequires relicsmpcore.admin permission.");
                }
            } else if (displayName.contains("Force Start Meteor Event")) {
                if (player.hasPermission("relicsmpcore.admin")) {
                    plugin.getEventManager().startMeteorEvent();
                    player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0f, 1.0f);
                    player.closeInventory();
                } else {
                    ChatUtils.sendMessage(player, "&cRequires relicsmpcore.admin permission.");
                }
            } else if (displayName.contains("Force End Active Event")) {
                if (player.hasPermission("relicsmpcore.admin")) {
                    if (plugin.getEventManager().isActive()) {
                        plugin.getEventManager().endEvent();
                        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.4f);
                    } else {
                        ChatUtils.sendMessage(player, "&cNo active event is running right now.");
                    }
                    player.closeInventory();
                } else {
                    ChatUtils.sendMessage(player, "&cRequires relicsmpcore.admin permission.");
                }
            }
        }
    }
}
