package com.relicsmpcore.listeners;

import com.relicsmpcore.RelicSMPCore;
import com.relicsmpcore.models.Relic;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class RelicListener implements Listener {

    private final RelicSMPCore plugin;

    public RelicListener(RelicSMPCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || item.getType() == Material.AIR) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) return;

        // Check for Relic Fragment redemption
        if (meta.getDisplayName().equalsIgnoreCase("§b§lRelic Fragment")) {
            event.setCancelled(true);
            int amount = item.getAmount();
            plugin.getRelicFragmentManager().addFragments(player.getUniqueId(), 1);
            if (amount > 1) {
                item.setAmount(amount - 1);
            } else {
                player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            }
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
            player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0, 1, 0), 15, 0.5, 0.5, 0.5, 0.05);
            
            int total = plugin.getRelicFragmentManager().getFragments(player.getUniqueId());
            ChatUtils.sendMessage(player, "&a+1 Relic Fragment redeemed! Your current balance: &e" + total);
            return;
        }

        // Check which relic was used by identifying the display name matched against loaded relics
        for (Relic relic : plugin.getRelicManager().getRelics()) {
            String coloredRelicName = ChatUtils.color(relic.getName());
            if (meta.getDisplayName().equalsIgnoreCase(coloredRelicName)) {
                event.setCancelled(true);
                triggerRelicAbility(player, relic, item);
                return;
            }
        }
    }

    private void triggerRelicAbility(Player player, Relic relic, ItemStack item) {
        // Cooldown check
        if (plugin.getRelicManager().hasCooldown(player, relic.getId())) {
            long remaining = plugin.getRelicManager().getCooldownRemaining(player, relic.getId());
            ChatUtils.sendMessage(player, "&c" + relic.getName() + " &cis currently recharging! Please wait &e" + remaining + "s &cbefore re-use.");
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 0.5f);
            return;
        }

        boolean success = false;

        switch (relic.getId().toLowerCase()) {
            case "winds":
                // Relic of Winds: launch player in direction they are looking
                Vector velocity = player.getLocation().getDirection().multiply(1.8).setY(1.1);
                player.setVelocity(velocity);
                player.getWorld().spawnParticle(Particle.CLOUD, player.getLocation(), 40, 0.5, 0.1, 0.5, 0.2);
                player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_FLAP, 1.0f, 1.2f);
                success = true;
                break;

            case "ender":
                // Relic of Ender: 12 block flash teleport blink
                Location loc = player.getLocation();
                Vector dir = loc.getDirection().normalize();
                Location targetLoc = loc.clone().add(dir.multiply(15));
                
                // Keep safe from solid block teleports
                if (!targetLoc.getBlock().getType().isSolid()) {
                    player.teleport(targetLoc);
                    player.getWorld().spawnParticle(Particle.PORTAL, loc, 50, 0.2, 0.2, 0.2, 0.5);
                    player.getWorld().spawnParticle(Particle.PORTAL, targetLoc, 50, 0.2, 0.2, 0.2, 0.5);
                    player.playSound(targetLoc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
                    success = true;
                } else {
                    ChatUtils.sendMessage(player, "&cCannot blink into a solid obstruction!");
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_DIDGERIDOO, 1.0f, 0.8f);
                }
                break;

            case "titan":
                // Relic of Titan: Resistance IV and Strength II for 8 seconds
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 160, 3));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 1));
                player.getWorld().spawnParticle(Particle.TRIAL_SPAWNER_DETECTION_OMINOUS, player.getLocation(), 35, 0.4, 0.4, 0.4, 0.1);
                player.playSound(player.getLocation(), Sound.ENTITY_IRON_GOLEM_HURT, 1.2f, 0.6f);
                success = true;
                break;

            case "hunter":
                // Relic of Hunter: High speed custom arrow
                Arrow arrow = player.launchProjectile(Arrow.class);
                arrow.setVelocity(player.getLocation().getDirection().multiply(3.0));
                arrow.setCustomName("relic_hunter_arrow");
                player.playSound(player.getLocation(), Sound.ENTITY_WIND_CHARGE_THROW, 1.0f, 1.5f);
                success = true;
                break;

            case "fortune":
                // Relic of Fortune: consume to trigger temporary regeneration / haste IV boost
                player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 600, 3));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 300, 2));
                player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation(), 45, 0.6, 0.6, 0.6, 0.2);
                player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.3f);
                
                // If it is item based, we don't necessarily take it, just apply cooldown
                success = true;
                break;
        }

        if (success) {
            // Apply cooldown
            plugin.getRelicManager().setCooldown(player, relic.getId(), relic.getCooldown());
            
            // Log interaction
            plugin.getRelicManager().transferOwnership(relic.getId(), player.getUniqueId());
            ChatUtils.sendMessage(player, "&aAbility triggered: " + relic.getName() + " &a!");
        }
    }
}
