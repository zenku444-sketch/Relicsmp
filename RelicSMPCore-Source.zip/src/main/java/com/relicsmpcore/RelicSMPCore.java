package com.relicsmpcore;

import com.relicsmpcore.commands.RelicCoreCommand;
import com.relicsmpcore.listeners.MenuListener;
import com.relicsmpcore.listeners.RelicListener;
import com.relicsmpcore.managers.ConfigManager;
import com.relicsmpcore.managers.DataManager;
import com.relicsmpcore.managers.EventManager;
import com.relicsmpcore.managers.RelicManager;
import com.relicsmpcore.managers.MeteorLootManager;
import com.relicsmpcore.managers.RelicFragmentManager;
import com.relicsmpcore.utils.ChatUtils;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class RelicSMPCore extends JavaPlugin {

    private static RelicSMPCore instance;
    
    private ConfigManager configManager;
    private DataManager dataManager;
    private RelicManager relicManager;
    private EventManager eventManager;
    private MeteorLootManager meteorLootManager;
    private RelicFragmentManager relicFragmentManager;

    @Override
    public void onEnable() {
        instance = this;

        // Initialize Chat Colors Utility
        ChatUtils.init(this);

        // Load Configurations
        this.saveDefaultConfig();
        this.configManager = new ConfigManager(this);
        this.configManager.load();

        // Initialize Custom Files Storage
        this.dataManager = new DataManager(this);
        this.dataManager.setup();

        // Load Main Systems
        this.relicManager = new RelicManager(this);
        this.relicManager.loadRelics();

        this.relicFragmentManager = new RelicFragmentManager(this);
        this.relicFragmentManager.loadBalances();

        this.meteorLootManager = new MeteorLootManager(this);

        this.eventManager = new EventManager(this);
        this.eventManager.startScheduler();

        // Register Commands
        if (this.getCommand("relicsmpcore") != null) {
            this.getCommand("relicsmpcore").setExecutor(new RelicCoreCommand(this));
            this.getCommand("relicsmpcore").setTabCompleter(new RelicCoreCommand(this));
        }

        // Register Listeners
        Bukkit.getPluginManager().registerEvents(new RelicListener(this), this);
        Bukkit.getPluginManager().registerEvents(new MenuListener(this), this);

        // Schedule Auto-Save Task
        long saveTicks = this.configManager.getSaveIntervalMinutes() * 1200L;
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, () -> {
            getLogger().info("Auto-saving RelicSMPCore data...");
            savePluginData();
        }, saveTicks, saveTicks);

        getLogger().info("RelicSMPCore has been successfully enabled!");
    }

    @Override
    public void onDisable() {
        // Shutdown schedulers & save data
        if (this.eventManager != null) {
            this.eventManager.stopScheduler();
        }
        
        savePluginData();
        getLogger().info("RelicSMPCore data saved and plugin successfully disabled.");
    }

    public void savePluginData() {
        if (this.relicManager != null) {
            this.relicManager.saveRelics();
        }
        if (this.relicFragmentManager != null) {
            this.relicFragmentManager.saveBalances();
        }
        if (this.dataManager != null) {
            this.dataManager.savePlayersData();
            this.dataManager.saveRelicsData();
        }
    }

    public void reloadPlugin() {
        this.reloadConfig();
        this.configManager.load();
        this.relicManager.loadRelics();
        if (this.relicFragmentManager != null) {
            this.relicFragmentManager.loadBalances();
        }
        this.eventManager.restartScheduler();
        getLogger().info("RelicSMPCore configurations reloaded successfully!");
    }

    public static RelicSMPCore getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public DataManager getDataManager() {
        return dataManager;
    }

    public RelicManager getRelicManager() {
        return relicManager;
    }

    public EventManager getEventManager() {
        return eventManager;
    }

    public MeteorLootManager getMeteorLootManager() {
        return meteorLootManager;
    }

    public RelicFragmentManager getRelicFragmentManager() {
        return relicFragmentManager;
    }
}
